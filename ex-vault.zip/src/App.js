import React from 'react'
import Splash from './components/Splash';
import LogIn from './components/LogIn';
import SignUp from './components/SignUp';
import './App.css';

function App() {
    return (
        <div className='App'>
            <SignUp/>
        </div>
    )


}

export default App